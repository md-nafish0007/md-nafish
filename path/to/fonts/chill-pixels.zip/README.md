# Chill-Pixels
### Chill Pixels 像素风格字体。
<br>

4 styles。<br>
Free commercial use.<br/>




![Chill Pixels01](https://user-images.githubusercontent.com/87366329/145054458-2aef2939-e70f-4dfa-8b6c-3b27b29450be.jpg)<br/>
![Chill Pixels02](https://user-images.githubusercontent.com/87366329/145054484-33799403-d9cc-4ccd-b1d0-632f55c05634.jpg)<br/>
![Chill Pixels03](https://user-images.githubusercontent.com/87366329/145054497-b6eba95b-4821-4e8f-b693-5886f1bb8776.jpg)<br/>
![Chill Pixels04](https://user-images.githubusercontent.com/87366329/145054519-3d2816bc-60a7-48a4-b3a9-c816e38daabc.jpg)<br/>
![Chill Pixels05](https://user-images.githubusercontent.com/87366329/145054543-9b2837d3-9591-4127-bf33-138ff1bbf69c.jpg)<br/>
![Chill Pixels06](https://user-images.githubusercontent.com/87366329/145054573-25f28aca-eedc-42c5-a795-59c598fce59b.jpg)<br/>
![Chill Pixels07](https://user-images.githubusercontent.com/87366329/145054605-d13906e8-f436-45b4-b0fb-d4c750d60a96.jpg)<br/>
![Chill Pixels08](https://user-images.githubusercontent.com/87366329/145054621-263478d8-729d-4547-b26a-bf8c01a624ef.jpg)<br/>
![Chill Pixels09](https://user-images.githubusercontent.com/87366329/145054628-249537a2-0436-4c49-8cd8-aeb6e3d5bba2.jpg)<br/>
![Chill Pixels10](https://user-images.githubusercontent.com/87366329/145054643-0683ee6c-7d42-4b1e-a689-3059b2948231.jpg)<br/>
![Chill Pixels11](https://user-images.githubusercontent.com/87366329/145054664-d0e4150a-d662-40ba-9fac-9d6f4ff14830.jpg)<br/>
![Chill Pixels12](https://user-images.githubusercontent.com/87366329/145054690-c3bb5fba-8a90-43bb-b986-4e3fc3067a5b.jpg)<br/>
![Chill Pixels13](https://user-images.githubusercontent.com/87366329/145054719-6c7d1dac-2199-490b-b2ea-63cc0d293535.jpg)<br/>

