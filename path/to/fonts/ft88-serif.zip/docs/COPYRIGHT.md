Copyright (c) <03/05/2021>, <Eugénie Bidaut> (<www.eugéniebidaut.eu|eugenie.bidaut@protonmail.com>),
with Reserved Font Name <Latitude>,
with Reserved Font Name <Équateur>,
with Reserved Font Name <Abordage>.

Copyright (c) <03/05/2021, <Oriane Charvieux> (<www.orianecharvieux.fr|oriane.charvieux@gmail.com>),
Copyright (c) <03/05/2021, <Mandy Elbé> (<mdy.elbe@gmail.com>),
with Reserved Font Name <FT88>.

Copyright (c) <03/05/2021>, <Luna Delabre> (<delabre.lou@gmail.com>),
Copyright (c) <03/05/2021>, <Camille Depalle> (<camille.depalle@gmail.com>),
with Reserved Font Name <Louise>.

Copyright (c) <03/05/2021>, <Justine Herbel> (<www.justineherbel.com|justineherbel@hotmail.fr>),
Copyright (c) <03/05/2021>, <May Jolivet> (<mayjolivet@outlook.fr>),
with Reserved Font Name <Director>.

Copyright (c) <03/05/2021>, <Benjamin Gomez> (<www.depli-ds.com|b.gomez@depli-ds.com>),
with Reserved Font Name <Basalte>.
